package login;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class LoginSVC {
	Connection con = null;
	Statement stmt = null;


	static{
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			System.out.println("드라이버가 없습니다.");
		}
	
	}
	
	public void connect(){
		
		String url = "jdbc:oracle:thin:@localhost:1521:orcl";
		try {
			con = DriverManager.getConnection(url, "javalink", "javalink");
			System.out.println("Connection Success!");
		} catch (SQLException e) {
			System.out.println("Connection failed");
		}
	}
	
	
	
	public User login(String id, String password) {
		User user = null; // new User(id, passwd, passwd, 0, id, passwd);
		//LoginSVC svc = new LoginSVC(); 
		connect();
		
		try{	
			
			stmt = con.createStatement();
			
			String sql = "SELECT * FROM member WHERE id = '" + id + "' AND " + "password = '" + password + "'";
			ResultSet rs = stmt.executeQuery(sql);	//'aaa','aaa','홍길동',22,'남','a@a.com'
			// 결과가 여러개라면 while이나 for을 사용하지만 결과가 1개이므로 if문 사용 
						
			if(rs.next()){
				id = rs.getString(1);
				password = rs.getString(2);
				String name = rs.getString(3);
				int age = rs.getInt("age");
				String gender = rs.getString("gender");
				String email = rs.getString("email");
				user = new User(id, password, name , age , gender , email);
//				System.out.println(DbId+" : "+DbPasswdD+" : "+name+" : "+age+" : "+gender+" : "+email);
					
			}			
		
		}
		catch(SQLException se){
			se.printStackTrace();
		}
		finally{
			try{
//				stmt.close();
//				con.close();
				
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}
		return user;
	}


}
