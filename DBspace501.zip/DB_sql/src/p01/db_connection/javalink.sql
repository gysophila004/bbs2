-- 테이블 만들기
create table member1(
id VARCHAR2(15) primary key,
password varchar2(10),
name varchar2(10),
age number,
gender varchar2(5),
email varchar2(30)
);

--테이블에 데이터 넣기
insert into member1 values('hong2', '1234', 'hongkil', 20, '남' , 'hong@hong.com');
commit;

select * from member1;

-----------------------------------------------

create table goodsinfo(
	code char(5) not null primary key,
	name varchar2(30) not null,
	price number(8) not null,	-- not null : 값이 있어야만 한다(비어있어서는 안된다)
	maker varchar2(20)
	);
	
insert into goodsinfo values('10001', '디지털 TV', 15000, 'LG');
insert into goodsinfo values('10002', 'LED TV', 25000, '삼성');
insert into goodsinfo values('10003', 'A TV', 35000, '삼성');
insert into goodsinfo values('10004', 'B TV', 45000, 'LG');
insert into goodsinfo values('10005', 'C TV', 555000, 'LG');
commit;
