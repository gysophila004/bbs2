package p01.db_connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DBConnection_Update {
	public static void main(String[] args) {
		//delete goodsinfo where code='12222';
		Connection conn = null;
		Statement stmt = null;
		try {
			//Class.forName("java.lang.String")
			Class.forName("oracle.jdbc.driver.OracleDriver"); 
			String url ="jdbc:oracle:thin:@localhost:1521:orcl";					

			conn = DriverManager.getConnection(url,"javalink", "javalink");
			stmt = conn.createStatement();
			String query = "update goodsinfo set maker='LG' where code='10002'";
			int count = stmt.executeUpdate(query);	 // 정상처리시 count=1
			if(count > 0)
				System.out.println("데이터가 수정되었습니다.");
			else
				System.out.println("데이터가 수정되지 않았습니다.");
			
			conn.close();
		}  catch (ClassNotFoundException e) {
			System.out.println("Driver가 없음:: 해당 클래스를 찾을 수 없습니다");
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		System.out.println("정상종료");
		
	}

}
