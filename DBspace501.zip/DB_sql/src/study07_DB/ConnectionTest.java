package study07_DB;
//DB 연동 테스트 
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionTest {
	Connection con;
	
	// 가장 먼저 수행
	static{
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			System.out.println("Driver가 없음:: 해당 클래스를 찾을 수 없습니다");
			e.printStackTrace();
		}
		
		
	}
	public void connect(){
				
		try {	
			
			String url ="jdbc:oracle:thin:@localhost:1521:orcl";
			con = DriverManager.getConnection(url,"java", "java");
			System.out.println("Connection Success!");
			con.close();			
		} catch (SQLException e) {
			System.out.println("주소, id, pw가 다릅니다.");
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		

	}
	public static void main(String[] args) {
		//자기자신의 객체 생성
		ConnectionTest ct = new ConnectionTest();
		ct.connect();

	}
}


